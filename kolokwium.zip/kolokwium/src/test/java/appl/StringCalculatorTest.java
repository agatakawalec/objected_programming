package appl;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static org.junit.Assert.*;

public class StringCalculatorTest {
    @Test
    public void Add(){
        StringCalculator a=new StringCalculator("3");
        String z=a.Add("3");
        assertEquals(z,"6");
    }

    public void Multiply(){
        StringCalculator a=new StringCalculator("3");
        String z=a.Add("3");
        assertEquals(z,"9");
    }
}