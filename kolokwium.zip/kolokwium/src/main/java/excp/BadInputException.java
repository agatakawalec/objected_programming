package excp;
import java.lang.Exception;

public class BadInputException extends Exception {
}
