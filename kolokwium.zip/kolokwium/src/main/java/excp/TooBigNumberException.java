package excp;
import java.lang.Exception;

public class TooBigNumberException extends Exception {
}
