package excp;
import java.lang.Exception;

public class NothingToSubstractFromException extends Exception{
}
