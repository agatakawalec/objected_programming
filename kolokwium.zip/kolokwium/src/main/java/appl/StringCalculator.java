package appl;
import excp.BadInputException;
import excp.NothingToSubstractFromException;
import excp.TooBigNumberException;

import java.io.FileNotFoundException;
import java.lang.*;

public class StringCalculator extends Calculator implements Cloneable{
    private String result;

    public StringCalculator(String y) {
        this.result=y;
    }

    public String GetResult(){
        return this.result;
    }

    public void SetResult(String y){
        this.result=y;
    }

    public String Add(String x) {
        int foo=Integer.parseInt(x);
        int foo2=Integer.parseInt(result);
        x=Integer.toString(foo+foo2);
        System.out.println(x);
        return x;
    }
    public String Substract(String x) {
        int foo=Integer.parseInt(x);
        int foo2=Integer.parseInt(result);

        if(result.equals(null)) try {
            throw new NothingToSubstractFromException();
        } catch (NothingToSubstractFromException e) {
            e.printStackTrace();
        }

        if(x.equals(null)) try {
            throw new BadInputException();
        } catch (BadInputException e) {
            e.printStackTrace();
        }

        x=Integer.toString(foo2-foo);
        System.out.println(x);
        return x;
    }
    public String Multiply(String x) {
        int foo=Integer.parseInt(x);
        if(foo>5) try {
            throw new TooBigNumberException();
        } catch (TooBigNumberException e) {
            e.printStackTrace();
        }
        int foo2=Integer.parseInt(result);
        x=Integer.toString(foo-foo2);
        System.out.println(x);
        return x;
    }

    @Override
    public void SaveToFile(String x, String Filename) throws FileNotFoundException {
        super.SaveToFile(x, Filename);
    }

    public static void main(String[] argv){
        StringCalculator test=new StringCalculator("2");
        String test2= test.Add("4");
        test.Substract("1");
        test.Multiply("4");
        try {
            test.SaveToFile(test2, "Plik");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}
