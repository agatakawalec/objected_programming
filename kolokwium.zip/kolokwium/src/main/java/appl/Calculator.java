package appl;
import java.io.*;

abstract public class Calculator {
    public void SaveToFile(String x, String Filename) throws FileNotFoundException {
        try {
            File output = new File(Filename);
        }catch(Exception e){};

        FileOutputStream output = new FileOutputStream(Filename);
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(output));

        try {
            bufferedWriter.write(x);
            bufferedWriter.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            bufferedWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String Add(String x){
        return x;
    }
    public String Substract(String x) {
        return x;
    }
    public String Multiply(String x) {
        return x;
    }

}
